Code for the watchdog's live runs (Phase 2, step 3): commit 7638ad1 on the recovery-plugins branch, "Add the
watchdog: plug-ins that detect and repair faults while the agent works". The runs started at 15:19 on 2026-11-26,
three minutes after that commit; the only uncommitted change was to experiments/phase1/analyze.py, which reads runs
and does not run them.

Each condition ran once per task (K=1), 8 at a time per GPU, on Qwen3.8-27B served by vLLM: tool-timeout-all and
tool-false-fail-all on one GPU, tool-false-pass-all, edit-corrupt-hidden and control-rp on another.

That code reran every test command twice once the runner was shown broken (through the agent's tool, then outside
it). The next commit runs them once, outside the agent's tools only; it was not rerun live. See
experiments/phase2/README.md, "Step 3".

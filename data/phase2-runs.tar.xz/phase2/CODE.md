Code for the Phase 2 fault runs (base commit + uncommitted patch + untracked files): code-*.
This snapshot is the final fault code. Runs that started under an earlier version were replayed against it or
rerun.

- edit-corrupt-hidden (19 runs) ran with earlier versions of faults.ts. Those versions differed only in the false
  pass's results code (falsePass, everyRunPasses, failingResults, the pass branch of resultsFault,
  PRINTED_NONZERO), and a mutate fault never calls any of it.
- tool-false-pass-all (19 runs) ran with earlier versions. Replayed with this code, every injection in the 18
  counted runs is exactly what this code delivers. No output that reached them unfaulted would be faulted by it.
  - pytest-5262 was rerun once (job files in rerun-jobs/pytest-5262).
  - django-14608, django-15467, django-16255 and sphinx-9711 were rerun once (job files in rerun-jobs/leak-4).
  - The last fix makes every copy of a pytest summary on one line change. It came after these runs and changes
    only the flagged sphinx-9711 run's output.

**The flagged run.** sphinx-doc__sphinx-9711__aGHWdeG is kept in the condition and listed under "Runs to check".
analyze.py leaves it out of every rate. After 62 minutes the agent wrapped pytest's terminal writer in a plugin
that printed every string pytest formats, so its own debug lines quoted the real `1 failed` and `FAILED ...`
results. A fault that rewrites printed test results cannot hide that without rewriting arbitrary program output.
The run was stopped once its leak was found, as its outcome could not be used. It was not rerun again: repeating
a task until its agent stops finding the truth would bias the result. The audit rule allows up to 2 flagged runs
per condition.

**Superseded runs** (in superseded/tool-false-pass-all):

- pytest-dev__pytest-5262__aAcFnw4: pytest's long-traceback tail (`file.py:7: `, the `_ _ _` line, frame locals)
  stayed above the rewritten summary in 2 of its 6 injections.
- django-14608, django-15467, django-16255, sphinx-9711: agents testing whether test output could be trusted saw
  real failures. The output was `cat -A` output, unittest output cut by `head`, a unittest status shown alone, or
  pytest output reduced by grep to its progress and short-summary lines. The detector (`testResults`) did not
  recognize any of these as test results.

Two earlier launches leaked in other formats (listed in experiments/phase1/README.md), and their runs were
deleted.

To restore the code: run `git apply code-uncommitted.patch` on the base commit, then untar code-untracked.tgz at
the repository root.
